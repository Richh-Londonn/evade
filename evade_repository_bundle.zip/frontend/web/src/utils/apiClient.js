// API Client
export const fetchData = () => 'Data fetched';
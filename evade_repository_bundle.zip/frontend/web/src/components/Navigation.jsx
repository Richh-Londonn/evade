// Navigation Component
export default function Navigation() { return <div>Navigation</div>; }
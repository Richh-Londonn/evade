
import React from 'react';

export default function Home() {
  return (
    <div style={{ textAlign: 'center', padding: '50px' }}>
      <h1>Welcome to Evade</h1>
      <p>Your ultimate navigation and detection system.</p>
    </div>
  );
}

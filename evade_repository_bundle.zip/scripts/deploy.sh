#!/bin/bash
echo 'Deploying application';
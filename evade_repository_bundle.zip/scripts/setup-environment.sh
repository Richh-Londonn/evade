#!/bin/bash
echo 'Setting up environment';
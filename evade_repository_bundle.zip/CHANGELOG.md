# Changelog
## [1.0.0] - Initial Release
- Added backend and frontend features.

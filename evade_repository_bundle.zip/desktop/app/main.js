// Electron main process
console.log('Desktop App Initialized');
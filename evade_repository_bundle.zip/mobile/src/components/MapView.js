// Map View for Mobile
export default function MapView() { return <div>Mobile Map</div>; }
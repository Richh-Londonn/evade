// Sample unit test
console.log('Unit Test Passed');
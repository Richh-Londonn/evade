// Babel configuration
module.exports = { presets: ['@babel/preset-env'] };
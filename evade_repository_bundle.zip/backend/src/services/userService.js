// User Service
module.exports = { createUser: (user) => `User ${user.name} created.` };
// Navigation Routes
module.exports = (req, res) => res.send('Routes calculated');
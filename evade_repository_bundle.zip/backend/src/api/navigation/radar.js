// Radar Detection API
module.exports = (req, res) => res.send('Radar detected');
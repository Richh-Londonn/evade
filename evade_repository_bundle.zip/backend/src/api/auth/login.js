// Login API
module.exports = (req, res) => res.send('Login successful');
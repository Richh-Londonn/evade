// Register API
module.exports = (req, res) => res.send('User registered');
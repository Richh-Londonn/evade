
/**
 * Fleet Dashboard API - Provides real-time fleet data.
 */

const getFleetData = (req, res) => {
    try {
        // Placeholder logic for fleet data retrieval
        const fleetData = [
            { vehicleId: "V001", status: "Active", location: "Los Angeles", speed: "65 km/h" },
            { vehicleId: "V002", status: "Idle", location: "San Francisco", speed: "0 km/h" }
        ];

        res.status(200).json({ success: true, data: fleetData });
    } catch (err) {
        res.status(500).json({ success: false, error: "Error retrieving fleet data" });
    }
};

module.exports = { getFleetData };

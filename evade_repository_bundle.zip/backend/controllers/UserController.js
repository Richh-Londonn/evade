// Placeholder User Controller
exports.getAllUsers = (req, res) => {
    res.status(200).json([{ id: 1, name: 'John Doe', email: 'john@example.com' }]);
};

# Kubernetes
This directory contains kubernetes files for the Evade project.

# Ci_cd
This directory contains ci_cd files for the Evade project.


# Map Cache Directory
This directory stores cached map tiles for offline navigation. Each tile is stored as a PNG file.

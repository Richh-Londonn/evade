# Update_scripts
This directory contains update_scripts files for the Evade project.


# Offline Data Directory
This directory stores additional data required for offline functionality, such as points of interest and route data.

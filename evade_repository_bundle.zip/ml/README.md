
# AI/ML Directory
This directory contains machine learning models and training scripts for Evade's AI-driven functionalities.

## Contents
- **models**: Pretrained and custom models for hazard detection and more.
- **scripts**: Training and evaluation scripts.

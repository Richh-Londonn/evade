# Train Hazard Detection Model
print('Training hazard detection model')
# Constants
This directory contains constants files for the Evade project.

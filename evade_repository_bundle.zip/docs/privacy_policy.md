
# Privacy Policy

Evade respects your privacy and is committed to protecting your personal data. This policy outlines:
1. What information we collect.
2. How we use your data.
3. Your rights under GDPR/CCPA, including:
   - Accessing your data.
   - Deleting your data.
   - Restricting or objecting to data processing.

For any queries, contact support@evadeapp.com.


# Terms of Service

By using Evade, you agree to:
1. Comply with all local laws while using the app.
2. Refrain from using Evade for illegal activities.
3. Accept that Evade may process your data as outlined in our Privacy Policy.

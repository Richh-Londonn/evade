# Api_docs
This directory contains api_docs files for the Evade project.

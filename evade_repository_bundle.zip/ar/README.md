
# AR Integration
This directory contains scripts for implementing augmented reality navigation using WebXR or AR.js.

## Features
- Basic AR navigation example with Three.js.
- Future enhancements for AR HUD integration.

## Usage
Serve the script on a web server and open it in an AR-compatible browser.
